export default function AboutPage() {
  return (
    <div style={{ padding: "2rem" }}>
      <h2>Biz Kimiz?</h2>
      <p>CanPay, kadınların gücünü paylaşarak büyüttüğü bir platformdur.</p>
    </div>
  );
}
