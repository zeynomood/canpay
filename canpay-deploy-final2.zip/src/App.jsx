
export default function App() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif', textAlign: 'center' }}>
      <h1>CanPay'e Hoş Geldiniz</h1>
      <p>Bu sayfa CanPay projesinin başlangıcıdır. ❤️</p>
    </div>
  );
}
